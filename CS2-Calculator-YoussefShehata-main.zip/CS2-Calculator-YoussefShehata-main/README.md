Youssef's CS2 Calculator
This is a calculator that calculates number using C++ programming

In order to create a calculator_app and run it:
I created a build directory with mkdir, then i entered it. I proceeded to cmake then make. Make did not work so I used another solution of g++. 

In order to run I type ./calculator_app.


